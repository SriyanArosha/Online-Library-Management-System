<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBookDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('book_details', function (Blueprint $table) {
            $table->increments('book_id');
            $table->string('isbn',50);
            $table->string('name',100);
            $table->string('author',100);
            $table->string('publisher',100);
            $table->string('category_id',50);
            $table->foreign('category_id')->references('category_id')->on('book_categories');
            $table->string('description',500);
            $table->string('no_of_copies');
            $table->string('cover_image');
            $table->string('publication_year');
            $table->timestamps();
            $table->primary('isbn');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('book_details');
    }
}
