<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookCategories extends Model
{
    protected $table = 'book_categories';

    protected $fillable=['category_id','category_name','description'];
}
