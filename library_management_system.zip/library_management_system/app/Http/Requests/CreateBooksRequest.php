<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateBooksRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'isbn'=>'required',
            'name'=>'required',
            'author'=>'required',
            'publisher'=>'required',
            'category_id'=>'required',
            'description'=>'required',
            'no_of_copies'=>'required',
            'cover_image'=>'required',
            'publication_year'=>'required',
        ];
    }
}
