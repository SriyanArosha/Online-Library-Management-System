<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class AuthenticateGuestUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        
        $role_name = Auth::user()->role;
        if($role_name === 'guestuser') {
            return $next($request);
        } else {
            abort(403, 'You cannot access this area!!!');
        }  
    }
}
