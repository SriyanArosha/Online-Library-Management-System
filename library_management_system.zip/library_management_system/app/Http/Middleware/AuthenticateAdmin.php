<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class AuthenticateAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $role_name = Auth::user()->role;
        if($role_name === 'admin') {
            return $next($request);
        } else {
            abort(403, 'You cannot access this area!!!');
        }    
            
    }
}
