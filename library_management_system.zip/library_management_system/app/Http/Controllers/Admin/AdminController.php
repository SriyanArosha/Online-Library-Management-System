<?php

namespace App\Http\Controllers\Admin;

use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\BookCategories;
use App\BookDetails;
use App\Http\Requests;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    /**
     * This function  creates a new book registry form
     **/
    public function create_new_book()
    {
        $categories = BookCategories::get();

        return view('admin.createbooks',compact('categories'));
    }

    /**
     * This function  stores the values of all book details
     **/
    public function insert_new_book(Request $request)
    {
        $image = $request['cover_image'];

        if($image != null) {
            $name = $image->getClientOriginalName();
            $destinationPath = public_path('images\book_cover_img');
            $status = $image->move($destinationPath, $name);
            if($status) {
                $image_original = $name;
            }
            else {
                session()->flash('fail',"Upload Error!!!");
            }
        }
        else {
            $image_original="sample.jpg";
        }

        $validator = Validator::make($request->all(), [
            'isbn'=>'required',
            'name'=>'required',
            'author'=>'required',
            'publisher'=>'required',
            'category_id'=>'required',
            'description'=>'required',
            'no_of_copies'=>'required',
            'publication_year'=>'required',
        ]);

        if ($validator->fails()) {
            return redirect('admin/create')
                        ->withErrors($validator)
                        ->withInput();
        } else {
            $status = BookDetails::create(['isbn'=>$request['isbn'],'name'=>$request['name'],'author'=>$request['author'],'publisher'=>$request['publisher'],'category_id'=>$request['category_id'],'description'=>$request['description'],'no_of_copies'=>$request['no_of_copies'],'cover_image'=>$image_original,'publication_year'=>$request['publication_year']]);

            if($status != null) {
                session()->flash('success',"Successfully created a new book");
            } else {
                session()->flash('fail',"Failed to access the database. Please try again!!!");
            }
        }

        $categories = BookCategories::get();
        
        return view('admin.createbooks',compact('categories'));
    }

    /**
     * This function  views existing book details
     **/
    public function view_books()
    {
        $book_details = BookDetails::get();

        return view('admin.viewbooks',compact('book_details'));
    }

    /**
     * This function  creates a form which updates values of relevant book
     **/
    public function change_book_details($book_id)
    {
        $book_details = BookDetails::where('book_id',$book_id)->get();

        $details_array = $book_details->toArray();

        $categories = BookCategories::get();

        return view('admin.updatebooks',compact('details_array','categories'));
    }

    /**
     * This function  updates the values of relevant book
     **/
    public function update_book_details(Request $request)
    {
       $image = $request['cover_image'];

        if($image != null) {
            $name = $image->getClientOriginalName();
            $destinationPath = public_path('images\book_cover_img');
            $status = $image->move($destinationPath, $name);
            if($status) {
                $image_original = $name;
            }
            else {
                session()->flash('fail',"Upload Error!!!");
            }
        }
        else {
            $image_original = $request['cover_image_original'];
        }

        $validator = Validator::make($request->all(), [
            'isbn'=>'required',
            'name'=>'required',
            'author'=>'required',
            'publisher'=>'required',
            'category_id'=>'required',
            'description'=>'required',
            'no_of_copies'=>'required',
            'publication_year'=>'required',
        ]);

        if ($validator->fails()) {
            return redirect('admin/update/'.$request['book_id'])
                        ->withErrors($validator)
                        ->withInput();
        } else {
            $data = array(
            'isbn' => $request['isbn'],
            'name' => $request['name'],
            'author' => $request['author'],
            'publisher' => $request['publisher'],
            'category_id' => $request['category_id'],
            'description' => $request['description'],
            'no_of_copies' => $request['no_of_copies'],
            'cover_image' => $image_original,
            'publication_year' => $request['publication_year'],
            );

            $status = BookDetails::where('book_id',$request['book_id'])->update($data);

            if($status != null) {
                session()->flash('success',"Successfully updated the book details");
            } else {
                session()->flash('fail',"Failed to access the database. Please try again!!!");
            }
        }

        $book_details = BookDetails::where('book_id',$request['book_id'])->get();

        $details_array = $book_details->toArray();

        $categories = BookCategories::get();
                
        return view('admin.updatebooks',compact('details_array','categories'));
    }

    /**
     * This function  views relevant book details
     **/
    public function view_single_book($book_id)
    {
        $book_details = BookDetails::where('book_id',$book_id)->get();

        $details_array = $book_details->toArray();

        $category = BookCategories::where('category_id',$details_array[0]['category_id'])->get();

        $category_array = $category->toArray();

        return view('admin.viewsinglebook',compact('details_array','category_array'));
    }

    /**
     * This function deletes a book from list
     **/
    public function delete_book($book_id)
    {
        BookDetails::where('book_id',$book_id)->delete();

        $book_details = BookDetails::get();

        return view('admin.viewbooks',compact('book_details'));
    }


    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
