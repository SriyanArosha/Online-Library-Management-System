<?php

namespace App\Http\Controllers\GuestUser;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\BookCategories;
use App\BookDetails;

class GuestUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    /**
     * This function  search books within the table
     **/
    public function search_books()
    {
        $book_details = BookDetails::get();

        return view('guestuser.searchbooks',compact('book_details'));
    }

    /**
     * This function  views relevant book details
     **/
    public function view_book($book_id)
    {
        $book_details = BookDetails::where('book_id',$book_id)->get();

        $details_array = $book_details->toArray();

        $category = BookCategories::where('category_id',$details_array[0]['category_id'])->get();

        $category_array = $category->toArray();

        return view('guestuser.viewbook',compact('details_array','category_array'));
    }



    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
