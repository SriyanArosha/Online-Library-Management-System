<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookDetails extends Model
{
    protected $table = 'book_details';

    protected $fillable=[
        'isbn',
        'name',
        'author',
        'publisher',
        'category_id',
        'description',
        'no_of_copies',
        'cover_image',
        'publication_year'
        ];
}
