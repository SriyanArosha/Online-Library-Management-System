<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="description" content="Online Library Management System">
  	<meta name="keywords" content="Library Management System,System,Library Management,Online Library">
  	<meta name="author" content="Arosha Perera">
    <meta name="viewport" content="width=device-width,initial-scale=1">

	<title>Library Management System</title>

	<!-- STYLESHEETS -->
	<link rel="stylesheet" type="text/css" href="{{asset('./css/style.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('./css/bootstrap.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('./css/bootstrap.min.css')}}" />
	<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" />
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" />
	<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.css" />
	<!-- END STYLESHEETS -->

	<!-- JS SCRIPTS -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/jqueryui/dataTables.jqueryui.js"></script>
	<!-- END JS SCRIPTS -->
</head>
<body>
	<div id="wrapper">
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="navbar-header pull-left">
    			<a class="navbar-brand" href="{{url('')}}">
        			<img src="{{asset('images/logo.png')}}" height="70" alt="logo">
    			</a>
			</div>
			<ul class="nav navbar-header pull-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fas fa-user"></i>&nbsp;{{ Auth::user()->name }}<b class="caret"></b></a>
                    <ul class="dropdown-menu" id="user-settings">
                        <li>
                            <a href="#"><i class="fas fa-user-cog"></i>&nbsp;Profile</a>
                        </li>
                        <li>
                            <a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
                                                     <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                        </li>
                    </ul>
                </li>
            </ul>
		</nav>
		<div id="page-wrapper">
            <div class="container">
                 @yield('content')
            </div>
        </div>
	</div>
	<footer>Copyright &copy; 2018 Arosha Perera</footer>
</body>