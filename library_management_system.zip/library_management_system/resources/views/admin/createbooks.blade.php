@extends('layouts.layout_master')

@section('content')

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box">
						@if (session('success'))
        				<div class="alert alert-success">
            			{{ session('success') }}
       					 </div>
                         @elseif (session('fail'))
                        <div class="alert alert-danger">
                        {{ session('fail') }}
                         </div>
						@elseif(count($errors)>0)
        					<div class="alert alert-danger">
            					<ul>
                					@foreach($errors->all() as $error)
                    				<li>{{$error}}</li>
                					@endforeach
            					</ul>
        					</div>
    					@endif
                        <div>
                            <br/><input type="submit" class="btn btn-info" value="View All Books" onclick="window.location.href='{{url('admin/view')}}'" />
                        </div>
						<div class="box-header">
                            <br/><h3 class="box-title">Create new Book</h3>
                        </div><br/>
                        <div class="box-body">
                        	<div class="col-md-3"></div>
                        	<div class="col-md-6">
                        		<form class="form-vertical" method="post" action="{{url('admin/create')}}" enctype="multipart/form-data">
								{!! csrf_field() !!}
								<div class="form-group">
                                    <label for="isbn">ISBN Number</label>
                                    <input type="text" id="isbn" name="isbn" class="form-control" 
                                    placeholder="book isbn number goes here..." />
                                </div>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" id="name" name="name" class="form-control" placeholder="book name goes here..." />
                                </div>
                                <div class="form-group">
                                    <label for="author">Author</label>
                                    <input type="text" id="author" name="author" class="form-control" placeholder="book author name goes here..." />
                                </div>
                                <div class="form-group">
                                    <label for="publisher">Publisher</label>
                                    <input type="text" id="publisher" name="publisher" class="form-control" placeholder="book publisher name goes here..." />
                                </div>
                                <div class="form-group">
                                    <label for="category">Category</label>
                                    <select class="form-control" id="category_id" name="category_id">
                                    	<option value="">Select A Category</option>
                                    	@foreach($categories as $category)
                                    	<option value="{{$category['category_id']}}">{{$category['category_name']}}</option>
                                    	@endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                	<label for="description">Description</label>
                                	<textarea class="form-control" rows="4" id="description" name="description" placeholder="book description goes here..." maxlength="300"></textarea>
								</div>
								<div class="form-group">
                                	<label for="copies_number">Number of Copies</label>
                                	<input type="text" id="no_of_copies" name="no_of_copies" class="form-control" placeholder="Number of Copies goes here..." />
								</div>
								<div class="form-group">
                                	<label for="cover_image">Cover Image</label>
                                	<input type="file" class="form-control" name="cover_image" id="cover_image" accept=".png, .jpg, .jpeg">
								</div>
								<div class="form-group">
                                	<label for="published_year">Publication Year</label>
                                	<input type="number" id="publication_year" name="publication_year" class="form-control" min="1899" placeholder="Publication Year goes here..." />
								</div>

								<input type="submit" class="btn btn-primary" value="submit"/>

								</form><br/><br/>
                        	</div>
                        	<div class="col-md-3"></div>
                        </div>
					</div>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>

@endsection