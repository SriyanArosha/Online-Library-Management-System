@extends('layouts.layout_master')

@section('content')

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box">
                        @if (session('success'))
                        <div class="alert alert-success">
                        {{ session('success') }}
                         </div>
                         @elseif (session('fail'))
                        <div class="alert alert-danger">
                        {{ session('fail') }}
                         </div>
                         @endif
    					<div>
    						<br/><input type="submit" class="btn btn-info" value="Add New Book" onclick="window.location.href='{{url('admin/create')}}'" />
    					</div>
						<div class="box-header">
                            <br/><h3 class="box-title">View Books</h3>
                        </div><br/>
                        <div class="box-body">
                        		<table id="book_details" class="table table-condensed table-striped table-hover">
                        			<thead>
                        			<tr>
                        				<th>&nbsp;</th>
                        				<th>ISBN Number</th>
                        				<th>Name</th>
                        				<th>Author</th>
                        				<th>No. of Copies</th>
                        				<th>&nbsp;</th>
                        			</tr>
                        			</thead>
                        			<tbody>
                        			@foreach($book_details as $book_detail)
                        			<tr>
                        				<th>
                                            <img height="50px" src="{{asset('./images/book_cover_img/')}}/{{$book_detail['cover_image']}}" alt="{{$book_detail['name']}}" />
                                        </th>
                        				<th>{{$book_detail['isbn']}}</th>
                        				<th>{{$book_detail['name']}}</th>
                        				<th>{{$book_detail['author']}}</th>
                        				<th>{{$book_detail['no_of_copies']}}</th>
                        				<th>
                        					<div class="hidden-sm hidden-xs action-buttons">
												<a style="color:blue" href="{{url('admin/view/single')}}/{{$book_detail['book_id']}}">
                                                    <i class="fas fa-search-plus"></i>
                                                </a>
												<a style="color:green" href="{{url('admin/update')}}/{{$book_detail['book_id']}}">
													<i class="fas fa-edit"></i>
												</a>
												<a class="delete_button" style="color:red" href="{{url('admin/delete')}}/{{$book_detail['book_id']}}">
													<i class="fas fa-trash-alt"></i>
												</a>
											</div>
                                            <input type="text" name="book_id" id="book_id" hidden />
                        				</th>
                        			</tr>
                        			@endforeach
                        			</tbody>
                        		</table><br/>
                        </div>
					</div>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>
@endsection
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#book_details').dataTable({
        	"pagingType": "full_numbers"
        });
    });

    $(document).ready(function(){
        $('.delete_button').on("click", function(e){
            if(!confirm('Do you want to delete this book detail?')){
                e.preventDefault();
            }
        });
    });
</script>