@extends('layouts.layout_master')

@section('content')
<h1>Authentication Error</h1>
@endsection