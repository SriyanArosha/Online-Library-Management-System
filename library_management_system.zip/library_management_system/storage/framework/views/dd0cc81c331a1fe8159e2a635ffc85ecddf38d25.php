<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box">
						<?php if(session('success')): ?>
        				<div class="alert alert-success">
            			<?php echo e(session('success')); ?>

       					 </div>
						<?php elseif(count($errors)>0): ?>
        					<div class="alert alert-danger">
            					<ul>
                					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    				<li><?php echo e($error); ?></li>
                					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            					</ul>
        					</div>
    					<?php endif; ?>
                        <div>
                            <br/><input type="submit" class="btn btn-info" value="View All Books" onclick="window.location.href='<?php echo e(url('admin/view')); ?>'" />
                        </div>
						<div class="box-header">
                            <br/><h3 class="box-title">Update Book</h3>
                        </div><br/>
                        <div class="box-body">
                        	<div class="col-md-3"></div>
                        	<div class="col-md-6">
                        		<form class="form-vertical" method="post" action="<?php echo e(url('admin/update')); ?>/<?php echo e($details_array[0]['book_id']); ?>" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>

								<div class="form-group">
                                    <label for="isbn">ISBN Number</label>
                                    <input type="text" id="isbn" name="isbn" class="form-control" 
                                    value="<?php echo e($details_array[0]['isbn']); ?>" />
                                </div>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" id="name" name="name" class="form-control" value="<?php echo e($details_array[0]['name']); ?>" />
                                </div>
                                <div class="form-group">
                                    <label for="author">Author</label>
                                    <input type="text" id="author" name="author" class="form-control" value="<?php echo e($details_array[0]['author']); ?>" />
                                </div>
                                <div class="form-group">
                                    <label for="publisher">Publisher</label>
                                    <input type="text" id="publisher" name="publisher" class="form-control" value="<?php echo e($details_array[0]['publisher']); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label for="category">Category</label>
                                    <select class="form-control" id="category_id" name="category_id">
                                    	<option value="">Select A Category</option>
                                    	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($category['category_id'] == $details_array[0]['category_id']): ?>  
                                        selected
                                        <?php endif; ?>
                                        value="<?php echo e($category['category_id']); ?>"> <?php echo e($category['category_name']); ?> 
                                        </option>
                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                	<label for="description">Description</label>
                                	<textarea class="form-control" rows="4" id="description" name="description"><?php echo e($details_array[0]['description']); ?></textarea>
								</div>
								<div class="form-group">
                                	<label for="copies_number">Number of Copies</label>
                                	<input type="text" id="no_of_copies" name="no_of_copies" class="form-control" value="<?php echo e($details_array[0]['no_of_copies']); ?>" />
								</div>
								<div class="form-group">
                                	<label for="cover_image">Cover Image</label><br/>
                                    <img height="150px" src="<?php echo e(asset('./images/book_cover_img/')); ?>/<?php echo e($details_array[0]['cover_image']); ?>" alt="Product Image" /><br/><br/>
                                    <input type="text" name="cover_image_original" id="cover_image_original" value="<?php echo e($details_array[0]['cover_image']); ?>" hidden />
                                	<input type="file" class="form-control" name="cover_image" id="cover_image" accept=".png, .jpg, .jpeg">
								</div>
								<div class="form-group">
                                	<label for="published_year">Publication Year</label>
                                	<input type="number" id="publication_year" name="publication_year" class="form-control" min="1899" value="<?php echo e($details_array[0]['publication_year']); ?>" />
								</div>

                                <input type="text" name="book_id" id="book_id" value="<?php echo e($details_array[0]['book_id']); ?>" hidden />
								<input type="submit" class="btn btn-primary" value="Update"/>

								</form><br/><br/>
                        	</div>
                        	<div class="col-md-3"></div>
                        </div>
					</div>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>