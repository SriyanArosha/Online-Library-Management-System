<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box">
						<div class="box-header">
                            <br/><h3 class="box-title">Search Books</h3>
                        </div><br/>
                        <div class="box-body">
                        		<table id="book_details" class="table table-condensed table-striped table-hover">
                        			<thead>
                        			<tr>
                        				<th>&nbsp;</th>
                        				<th>ISBN Number</th>
                        				<th>Name</th>
                        				<th>Author</th>
                        				<th>No. of Copies</th>
                        				<th>&nbsp;</th>
                        			</tr>
                        			</thead>
                        			<tbody>
                        			<?php $__currentLoopData = $book_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        			<tr>
                        				<th>
                                            <img height="50px" src="<?php echo e(asset('./images/book_cover_img/')); ?>/<?php echo e($book_detail['cover_image']); ?>" alt="<?php echo e($book_detail['name']); ?>" />
                                        </th>
                        				<th><?php echo e($book_detail['isbn']); ?></th>
                        				<th><?php echo e($book_detail['name']); ?></th>
                        				<th><?php echo e($book_detail['author']); ?></th>
                        				<th><?php echo e($book_detail['no_of_copies']); ?></th>
                        				<th>
                        					<div class="hidden-sm hidden-xs action-buttons">
												<a style="color:blue" href="<?php echo e(url('guest/view')); ?>/<?php echo e($book_detail['book_id']); ?>">
                                                    <i class="fas fa-search-plus"></i>
                                                </a>
											</div>
                        				</th>
                        			</tr>
                        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        			</tbody>
                        		</table><br/>
                        </div>
					</div>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#book_details').dataTable({
        	"pagingType": "full_numbers",
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        });
    });
</script>
<?php echo $__env->make('layouts.layout_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>