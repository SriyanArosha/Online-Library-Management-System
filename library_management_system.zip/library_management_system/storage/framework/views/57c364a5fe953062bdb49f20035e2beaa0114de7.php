<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                         </div>
                    <?php elseif(session('fail')): ?>
                        <div class="alert alert-danger">
                        <?php echo e(session('fail')); ?>

                         </div>
                     <?php endif; ?>
    				<div>
    					<br/>
                        <a href="<?php echo e(url('admin/view')); ?>">Back to Books List Page</a>
    				</div><br/>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>