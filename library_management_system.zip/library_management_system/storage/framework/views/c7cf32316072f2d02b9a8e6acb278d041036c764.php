<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box">
                        <div>
                            <br/><input type="submit" class="btn btn-info" value="View All Books" onclick="window.location.href='<?php echo e(url('admin/view')); ?>'" />
                        </div>
						<div class="box-header">
                            <br/><h3 class="box-title"></h3>
                        </div><br/>
                        <div class="box-body">
                        		<form class="form-vertical">
								<div class="form-group">
                                    <label for="isbn">ISBN Number</label>
                                    <input type="text" class="form-control" 
                                    value="<?php echo e($details_array[0]['isbn']); ?>" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" value="<?php echo e($details_array[0]['name']); ?>" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="author">Author</label>
                                    <input type="text" class="form-control" value="<?php echo e($details_array[0]['author']); ?>" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="publisher">Publisher</label>
                                    <input type="text" class="form-control" value="<?php echo e($details_array[0]['publisher']); ?>" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="category">Category</label>
                                    <input type="text" class="form-control" value="<?php echo e($category_array[0]['category_name']); ?>" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea class="form-control" rows="4" readonly><?php echo e($details_array[0]['description']); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="copies_number">Number of Copies</label>
                                    <input type="text" class="form-control" value="<?php echo e($details_array[0]['no_of_copies']); ?>" />
                                </div>
                                <div class="form-group">
                                    <label for="cover_image">Cover Image</label><br/>
                                    <img height="200px" src="<?php echo e(asset('./images/book_cover_img/')); ?>/<?php echo e($details_array[0]['cover_image']); ?>" alt="Book Image" />
                                </div>
                                <div class="form-group">
                                    <label for="published_year">Publication Year</label>
                                    <input type="text" class="form-control" value="<?php echo e($details_array[0]['publication_year']); ?>" />
                                </div>

								</form><br/><br/>
                        </div>
					</div>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>