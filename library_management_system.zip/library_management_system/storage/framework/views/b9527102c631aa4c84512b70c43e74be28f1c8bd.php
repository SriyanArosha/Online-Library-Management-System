<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
	<div class="panel panel-default">
		<div class="panel panel-body">
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                         </div>
                         <?php elseif(session('fail')): ?>
                        <div class="alert alert-danger">
                        <?php echo e(session('fail')); ?>

                         </div>
                         <?php endif; ?>
    					<div>
    						<br/><input type="submit" class="btn btn-info" value="Add New Book" onclick="window.location.href='<?php echo e(url('admin/create')); ?>'" />
    					</div>
						<div class="box-header">
                            <br/><h3 class="box-title">View Books</h3>
                        </div><br/>
                        <div class="box-body">
                        		<table id="book_details" class="table table-condensed table-striped table-hover">
                        			<thead>
                        			<tr>
                        				<th>&nbsp;</th>
                        				<th>ISBN Number</th>
                        				<th>Name</th>
                        				<th>Author</th>
                        				<th>No. of Copies</th>
                        				<th>&nbsp;</th>
                        			</tr>
                        			</thead>
                        			<tbody>
                        			<?php $__currentLoopData = $book_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        			<tr>
                        				<th>
                                            <img height="50px" src="<?php echo e(asset('./images/book_cover_img/')); ?>/<?php echo e($book_detail['cover_image']); ?>" alt="<?php echo e($book_detail['name']); ?>" />
                                        </th>
                        				<th><?php echo e($book_detail['isbn']); ?></th>
                        				<th><?php echo e($book_detail['name']); ?></th>
                        				<th><?php echo e($book_detail['author']); ?></th>
                        				<th><?php echo e($book_detail['no_of_copies']); ?></th>
                        				<th>
                        					<div class="hidden-sm hidden-xs action-buttons">
												<a style="color:blue" href="<?php echo e(url('admin/view/single')); ?>/<?php echo e($book_detail['book_id']); ?>">
                                                    <i class="fas fa-search-plus"></i>
                                                </a>
												<a style="color:green" href="<?php echo e(url('admin/update')); ?>/<?php echo e($book_detail['book_id']); ?>">
													<i class="fas fa-edit"></i>
												</a>
												<a style="color:red" href="<?php echo e(url('admin/delete')); ?>/<?php echo e($book_detail['book_id']); ?>">
													<i class="fas fa-trash-alt"></i>
												</a>
											</div>
                                            <input type="text" name="book_id" id="book_id" hidden />
                        				</th>
                        			</tr>
                        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        			</tbody>
                        		</table><br/>
                        </div>
					</div>
				</div>
			</div>
		</section>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#book_details').dataTable({
        	"pagingType": "full_numbers"
        });
    });
</script>
<?php echo $__env->make('layouts.layout_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>