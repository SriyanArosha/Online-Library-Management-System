<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

//Admin Routes
Route::group(['namespace' => 'Admin'], function() {
	Route::get('admin/create', 'AdminController@create_new_book');
	Route::post('admin/create', 'AdminController@insert_new_book');

	Route::get('admin/view', 'AdminController@view_books');
	Route::get('admin/view/single/{book_id}', 'AdminController@view_single_book');

	Route::get('admin/update/{book_id}', 'AdminController@change_book_details');
	Route::post('admin/update/{book_id}', 'AdminController@update_book_details');

	Route::get('admin/delete/{book_id}', 'AdminController@delete_book');
});

//Guest User Routes
Route::group(['namespace' => 'GuestUser'], function() {
	Route::get('guest/search', 'GuestUserController@search_books');
	Route::get('guest/view/{book_id}', 'GuestUserController@view_book');
});

Auth::routes();

Route::get('/home', 'HomeController@index');
